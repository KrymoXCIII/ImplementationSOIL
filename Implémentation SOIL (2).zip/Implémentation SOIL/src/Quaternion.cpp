#include <math.h>
#include <stdio.h>
#include "Quaternion.h"
#include "Matrice.h"
#include <stdlib.h>

#include <GL/gl.h>
#include <GL/glu.h>

#include "glut.h"
#include "SOIL.h"
Quaternion:: Quaternion() {}


Quaternion::Quaternion(float a,float b,float c,float d) {
    this->a=a;
    this->b=b;
    this->c=c;
    this->d=d;
}

void Quaternion::sum(Quaternion* qua) {
    a = a + qua->a;
    b = b + qua->b;
    c = c + qua->c;
    d = d + qua->d;
}

void Quaternion::product(Quaternion* qua) {

    a = (a * qua->a) - (b * qua->b) - (c * qua->c) - (d * qua->d);
    b = (a * qua->b) + (b * qua->a) + (c * qua->d) - (d * qua->c);
    c = (a * qua->c) - (b * qua->d) + (c * qua->a) + (d * qua->b);
    d = (a * qua->d) + (b * qua->c) - (c * qua->b) + (d * qua->a);
}


void Quaternion::conjugate() {
    b = -b;
    c = -c;
    d = -d;
}

float Quaternion::norm() {
    return sqrt(a*a+b*b+c*c+d*d);
}


float Quaternion::productScalar() {
    return a*a+b*b+c*c+d*d;
}

void Quaternion::unit(){
    a = a / norm();
    b = b / norm();
    c = c / norm();
    d = d / norm();
}
void Quaternion::printQ() {
    printf("%lf, %lf, %lf, %lf \n", a, b, c, d);
}

void Quaternion::productVect(Quaternion* qua){
    b = b * qua->b;
    c = c * qua->c;
    d = d * qua->d;
}

void Quaternion::toMatrix(float* tab){
    tab[0] = 1-2*pow(c, 2)-2*pow(d, 2);

    tab[1] = 2*b*c-2*d*a;

    tab[2] = 2*a*c+2*b*d;

    tab[3] = 0;

    tab[4] = 2*b*c+2*d*a;

    tab[5] = 1-2*pow(b, 2)-2*pow(d, 2);

    tab[6] = 2*c*d-2*b*a;

    tab[7] = 0;

    tab[8] = 2*b*d-2*c*a;
    tab[9] = 2*c*d+2*b*a;
    tab[10] = 1-2*pow(b, 2)-2*pow(c, 2);
    tab[11] = 0;
    tab[12] = 0;
    tab[13] =0;
    tab[14] = 0;
    tab[15] = 1;

}
void Quaternion::createRotation(float angle,float x,float y,float z){
    float unit = 1/sqrt(x+y+z);
    double rad = 0.5;
  // converting degrees to radians
     rad = angle*3.14159/180;
     a = cos(rad);
     b = x*sin(rad)*unit;
     c = y*sin(rad)*unit;
     d = z*sin(rad)*unit;
 }

 void Quaternion::RotatewithMatrix(){

     Quaternion* qua = new Quaternion(a,b,c,d);
     float tab[16];
     qua->toMatrix(tab);
     glMultMatrixf(tab);

}
void Quaternion::RotatewithQuater(){

     Quaternion* qua = new Quaternion(a,b,c,d);

     float tab[16];
     float tabGL[16];

    GLfloat matrix[16];
    glMatrixMode(GL_MODELVIEW);
    glGetFloatv(GL_MODELVIEW_MATRIX, matrix);
    Matrice mat(matrix);
    Quaternion quat = mat.ToQuat();
    quat.printQ();
    quat.product(qua);
    quat.toMatrix(tabGL);

    glLoadMatrixf(tabGL);

}
