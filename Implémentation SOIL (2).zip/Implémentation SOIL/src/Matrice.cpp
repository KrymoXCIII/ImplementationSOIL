#include "Matrice.h"
#include "Quaternion.h"
#include <math.h>
#include <algorithm>
#include <stdio.h>
Matrice::Matrice() {
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            this->matRot[i][j] = 0;
        }
    }
}

Matrice::Matrice(float mat[3][3]){
    int i,j = 0;
	for (i=0;i<3;i++)
	{
		for (j=0;j<3;j++)
			{
				this->matRot[i][j]=mat[i][j];
			}
	}
}

Matrice::Matrice(float mat[16]){
    int i = 0;
	for (i=0;i<16;i++)
	{
	    this->matGl[i]=mat[i];

	}
}

Matrice* Matrice::productMatrice(Matrice* mat1){
    Matrice* mat = new Matrice();
    float valMat;
    int n,m,i,j,k = 0;
    for(i = 0; i < n; i++)
    {
        for(j = 0; j < m; j++)
        {
          for(k = 0; k < m; k++)
          {
            valMat = mat1->matRot[i][k] * matRot[k][j];
          }
        }
    }
    return mat;
}

Quaternion Matrice::ToQuat()
{
    float Trace = matGl[0] + matGl[5] + matGl[10] + 1;
    float S = 0;
    float a,b,c,d,maximum = 0;
    if (Trace > 0){
        S = 0.5 / sqrt(Trace);
        a = (1/4)/S;
        b = (matGl[9] - matGl[6])*S;
        c = (matGl[2] - matGl[8])*S;
        d = (matGl[4] - matGl[1])*S;
        return Quaternion(a,b,c,d);
    }
    else {
        maximum = matGl[0];
        if (matGl[5]>=maximum){
           maximum = matGl[5];
        }
        if (matGl[10]>=maximum){
           maximum = matGl[10];
        }
        if (maximum == matGl[0]){
            S = sqrt(1+ matGl[0] - matGl[5] - matGl[10])*2;
            a = (matGl[9] - matGl[6])/S;
            b = (0.25)*S;
            c = (matGl[1] + matGl[4])/S;
            d = (matGl[2] + matGl[8])/S;
        }
        if (maximum == matGl[5]){
            S = sqrt(1- matGl[0] + matGl[5] - matGl[10])*2;
            a = (matGl[2] - matGl[8])/S;
            b = (matGl[1] + matGl[4])/S;
            c = 0.25*S;
            d = (matGl[6] + matGl[9])/S;
        }
        if (maximum == matGl[10]){
            S = sqrt(1- matGl[0] - matGl[5] + matGl[10])*2;
            a = (matGl[4] - matGl[1])/S;
            b = (matGl[2] + matGl[8])/S;
            c = (matGl[6] + matGl[9])/S;
            d = 0.25*S;
        }
        return Quaternion(a,b,c,d);
    }

}
