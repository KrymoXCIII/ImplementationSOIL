#ifndef MATRICE_H
#define MATRICE_H
#include "Quaternion.h"
class Quaternion;
class Matrice
{
    private:
        float matRot[3][3];
        float matGl[16];
    public:
        Matrice();
        Matrice(float matRot[3][3]);
        Matrice* productMatrice(Matrice* mat1);
        Quaternion ToQuat();
        Matrice(float mat[16]);
};

#endif // MATRICE_H
