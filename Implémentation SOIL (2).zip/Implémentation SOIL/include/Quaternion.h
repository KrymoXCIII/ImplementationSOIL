#ifndef QUATERNION_H
#define QUATERNION_H

#include <GL/gl.h>
#include <GL/glu.h>

#include "glut.h"
#include "SOIL.h"
#include "Matrice.h"
class Matrice;
class Quaternion
{
private:
    float a;
    float b;
    float c;
    float d;

public:
    Quaternion();
    Quaternion(float a, float b, float c, float d);
    void sum(Quaternion* q2);
    void product(Quaternion* q2);
    void conjugate();
    float norm();
    float productScalar();
    void printQ();
    void unit();
    void productVect();
    void productVect(Quaternion* qua);
    void toMatrix(float* tab);
    void RotatewithQuater();
    void createRotation(float angle,float x,float y,float z);
    void RotatewithMatrix();
};


#endif // QUATERNION_H
