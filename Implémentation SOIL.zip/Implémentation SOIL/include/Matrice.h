#ifndef MATRICE_H
#define MATRICE_H
#include "Quaternion.h"
class Quaternion;
class Matrice
{
        double matRot[3][3];
    public:
        Matrice();
        Matrice(double matRot[3][3]);
        Matrice* productMatrice(Matrice* mat1);
        Quaternion ToQuat();
};

#endif // MATRICE_H
