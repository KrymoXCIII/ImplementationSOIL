#ifndef QUATERNION_H
#define QUATERNION_H

#include <GL/gl.h>
#include <GL/glu.h>

#include "glut.h"
#include "SOIL.h"
#include "Matrice.h"
class Matrice;
class Quaternion
{
    double a;
    double b;
    double c;
    double d;

public:
    Quaternion();
    Quaternion(double a, double b, double c, double d);
    void sum(Quaternion* q2);
    void product(Quaternion* q2);
    void conjugate();
    double norm();
    double productScalar();
    void printQ();
    void unit();
    void productVect();
    void productVect(Quaternion* qua);
    Matrice toMatrix();
};

#endif // QUATERNION_H
