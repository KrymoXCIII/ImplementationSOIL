#include "Matrice.h"
#include "Quaternion.h"
#include <math.h>
#include <algorithm>
#include <stdio.h>
Matrice::Matrice() {
    for(int i = 0; i < 3; i++) {
        for(int j = 0; j < 3; j++) {
            this->matRot[i][j] = 0;
        }
    }
}

Matrice::Matrice(double mat[3][3]){
    int i,j = 0;
	for (i=0;i<3;i++)
	{
		for (j=0;j<3;j++)
			{
				this->matRot[i][j]=mat[i][j];
			}
	}
}
Matrice* Matrice::productMatrice(Matrice* mat1){
    Matrice* mat = new Matrice();
    double valMat;
    int n,m,i,j,k = 0;
    for(i = 0; i < n; i++)
    {
        for(j = 0; j < m; j++)
        {
          for(k = 0; k < m; k++)
          {
            valMat = mat1->matRot[i][k] * matRot[k][j];
          }
        }
    }
    return mat;
}

Quaternion Matrice::ToQuat()
{
    double Trace = matRot[0][0] + matRot[1][1] + matRot[2][2] + 1;
    double S = 0;
    double a,b,c,d,maximum = 0;
    if (Trace > 0){
        S = 0.5 / sqrt(Trace);
        a = (1/4)/S;
        b = (matRot[2][1] - matRot[1][2])*S;
        c = (matRot[0][2] - matRot[2][0])*S;
        d = (matRot[1][0] - matRot[0][1])*S;
        return Quaternion(a,b,c,d);
    }
    else {
        maximum = matRot[0][0];
        if (matRot[1][1]>=maximum){
           maximum = matRot[1][1];
        }
        if (matRot[2][2]>=maximum){
           maximum = matRot[2][2];
        }
        if (maximum == matRot[0][0]){
            S = sqrt(1+ matRot[0][0] - matRot[1][1] - matRot[2][2])*2;
            a = (matRot[2][1] - matRot[1][2])/S;
            b = (0.25)*S;
            c = (matRot[0][1] + matRot[1][0])/S;
            d = (matRot[0][2] + matRot[2][0])/S;
        }
        if (maximum == matRot[1][1]){
            S = sqrt(1- matRot[0][0] + matRot[1][1] - matRot[2][2])*2;
            a = (matRot[0][2] - matRot[2][0])/S;
            b = (matRot[0][1] + matRot[1][0])/S;
            c = 0.25*S;
            d = (matRot[1][2] + matRot[2][1])/S;
        }
        if (maximum == matRot[2][2]){
            S = sqrt(1- matRot[0][0] - matRot[1][1] + matRot[2][2])*2;
            a = (matRot[1][0] - matRot[0][1])/S;
            b = (matRot[0][2] + matRot[2][0])/S;
            c = (matRot[1][2] + matRot[2][1])/S;
            d = 0.25*S;
        }
        return Quaternion(a,b,c,d);
    }

}
