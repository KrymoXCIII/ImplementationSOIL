#include <math.h>
#include <stdio.h>
#include "Quaternion.h"
#include "Matrice.h"
Quaternion:: Quaternion() {}


Quaternion::Quaternion(double a,double b,double c,double d) {
    this->a=a;
    this->b=b;
    this->c=c;
    this->d=d;
}

void Quaternion::sum(Quaternion* qua) {
    a = a + qua->a;
    b = b + qua->b;
    c = c + qua->c;
    d = d + qua->d;
}

void Quaternion::product(Quaternion* qua) {

    a = (a * qua->a) - (b * qua->b) - (c * qua->c) - (d * qua->d);
    b = (a * qua->b) + (b * qua->a) + (c * qua->d) - (d * qua->c);
    c = (a * qua->c) - (b * qua->d) + (c * qua->a) + (d * qua->b);
    d = (a * qua->d) + (b * qua->c) - (c * qua->b) + (d * qua->a);
}


void Quaternion::conjugate() {
    b = -b;
    c = -c;
    d = -d;
}

double Quaternion::norm() {
    return sqrt(a*a+b*b+c*c+d*d);
}


double Quaternion::productScalar() {
    return a*a+b*b+c*c+d*d;
}

void Quaternion::unit(){
    a = a / norm();
    b = b / norm();
    c = c / norm();
    d = d / norm();
}
void Quaternion::printQ() {
    printf("%lf, %lf, %lf, %lf \n", a, b, c, d);
}

void Quaternion::productVect(Quaternion* qua){
    b = b * qua->b;
    c = c * qua->c;
    d = d * qua->d;
}

Matrice Quaternion::toMatrix(){
    double tab[3][3] = {{1-2*pow(c, 2)-2*pow(d, 2), 2*b*c-2*d*a, 2*a*c+2*b*d},
                       {2*b*c+2*d*a, 1-2*pow(b, 2)-2*pow(d, 2), 2*c*d-2*b*a},
                       {2*b*d-2*c*a, 2*c*d+2*b*a, 1-2*pow(b, 2)-2*pow(c, 2)}};
    return Matrice(tab);
}
